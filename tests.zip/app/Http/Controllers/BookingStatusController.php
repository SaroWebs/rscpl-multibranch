<?php

namespace App\Http\Controllers;

use App\Models\BookingStatus;
use Illuminate\Http\Request;

class BookingStatusController extends Controller
{
    // 
}
